<?php
session_start();

// --- DIAGNÓSTICO DE ERROS (MANTENHA ISSO ATIVADO TEMPORARIAMENTE) ---
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$configDir = __DIR__ . '/configs';
// Tenta criar o diretório, se falhar, o script pode parar aqui com erro de permissão.
if (!is_dir($configDir)) {
    @mkdir($configDir);
}


// --- FUNÇÕES DE UTILIDADE ---

function add_output($text) {
    if (!isset($_SESSION['config']['output'])) {
        $_SESSION['config']['output'] = [];
    }
    // O texto é adicionado com uma quebra de linha (se não for o prompt)
    $_SESSION['config']['output'][] = $text;
    // Limita o buffer de saída para 100 linhas
    if (count($_SESSION['config']['output']) > 100) {
        array_shift($_SESSION['config']['output']);
    }
}

function get_current_interface_name() {
    return isset($_SESSION['config']['current_interface']) ? $_SESSION['config']['current_interface'] : null;
}

// Retorna o nome do serviço ou interface/protocolo atual para o prompt
function get_current_context_name() {
    if (isset($_SESSION['config']['current_interface'])) {
        return $_SESSION['config']['current_interface'];
    }
    if (isset($_SESSION['config']['current_service'])) {
        return $_SESSION['config']['current_service'];
    }
    if (isset($_SESSION['config']['current_protocol'])) {
        return $_SESSION['config']['current_protocol'];
    }
    return null;
}

function generate_uptime() {
    $days = rand(0, 30);
    $hours = rand(0, 23);
    $minutes = rand(0, 59);
    return "$days days, $hours hours, $minutes minutes"; // Traduzido
}

// Função para obter a string de prompt
function get_prompt_string($routerName, $mode, $contextName) {
    $routerName = strtoupper($routerName);
    if ($mode === 'normal') return "{$routerName}>";
    if ($mode === 'enable') return "{$routerName}#";
    if ($mode === 'configure') return "{$routerName}(config)#";
    
    // Modos Hierárquicos
    if ($mode === 'config-if' && $contextName) return "{$routerName}(config-if-{$contextName})#";
    if ($mode === 'config-service-vpls' && $contextName) return "{$routerName}(config-service-vpls-{$contextName})#";
    if ($mode === 'config-router-ospf' && $contextName) return "{$routerName}(config-router-ospf-{$contextName})#";
    if ($mode === 'config-router-ldp') return "{$routerName}(config-router-ldp)#"; 
    if ($mode === 'config-router-bgp') return "{$routerName}(config-router-bgp)#"; 
    
    if ($mode === 'password') return "Password:";
    return "{$routerName}>";
}

// Função para parsing de comando mais robusto
function parse_router_command($input) {
    $input = trim($input);
    if (empty($input)) {
        return ['command' => '', 'command_lower' => '', 'args_lower' => [], 'raw_args' => ''];
    }

    // Tenta separar a primeira palavra (o comando principal) do restante (argumentos)
    $parts = preg_split('/\s+/', $input, 2);
    $command_verb = array_shift($parts);
    $raw_args = isset($parts[0]) ? trim($parts[0]) : '';
    
    // Argumentos em lower case para correspondência de comandos (ex: 'secret' de 'enable secret')
    $args_lower = $raw_args ? preg_split('/\s+/', strtolower($raw_args)) : [];
    
    // Se o comando começa com 'no', trata-o como um comando principal
    if (strtolower($command_verb) === 'no' && !empty($raw_args)) {
         $full_no_command = strtolower($raw_args);
         // Retorna o comando 'no' com o resto como argumento bruto (raw_args)
         return [
             'command' => $command_verb, 
             'command_lower' => 'no',
             'args_lower' => $args_lower, 
             'raw_args' => $raw_args, 
         ];
    }
    
    return [
        'command' => $command_verb, 
        'command_lower' => strtolower($command_verb),
        'args_lower' => $args_lower, 
        'raw_args' => $raw_args, // String bruta dos argumentos (preserva case, quotes, espaços)
    ];
}


// --- DEFINIÇÕES DE COMANDOS E SUGESTÕES (TRADUZIDO) ---

$commands = [
    'normal' => [
        'enable' => 'Enters privileged EXEC mode (requires password if configured)',
        'exit' => 'Logs out and terminates the simulator session',
        'help' => 'Displays this help message',
        'clear' => 'Clears the terminal screen buffer',
        'save' => 'Saves the current configuration to disk',
    ],
    'enable' => [
        'configure' => 'Enters global configuration mode',
        'show interfaces' => 'Displays all interfaces (physical and virtual) status',
        'show services' => 'Displays the status of services (VPLS, VPRN, etc.)',
        'show configuration' => 'Displays the full router configuration',
        'show version' => 'Displays operational status and uptime',
        'show clock' => 'Displays current date and time',
        'show ip route' => 'Displays the IP routing table',
        'ping' => 'Sends ICMP echo requests',
        'reload' => 'Restarts the router and the session',
        'exit' => 'Exits privileged EXEC mode',
        'help' => 'Displays this help message',
        'clear' => 'Clears the terminal screen buffer',
        'save' => 'Saves the current configuration to disk',
    ],
    'configure' => [
        'hostname' => 'Sets the router name',
        'no hostname' => 'Removes the router name (resets to default)',
        'enable secret' => 'Sets the password for privileged EXEC mode',
        'no enable secret' => 'Removes the password for privileged EXEC mode',
        'ip default-gateway' => 'Sets the default gateway',
        'no ip default-gateway' => 'Removes the default gateway',
        'interface' => 'Selects or creates an interface for configuration (Ex: interface 1/1/1)',
        'no interface' => 'Removes an interface or loopback (Ex: no interface 1/1/1)',
        'interface loopback' => 'Selects or creates a loopback interface (Ex: interface loopback 1)',
        'service vpls' => 'Creates a new VPLS service (Requires: ID customer ID create)',
        'no service vpls' => 'Removes a VPLS service (Ex: no service vpls 10)',
        'router ospf' => 'Enters OSPF configuration context (Requires: ID)', 
        'no router ospf' => 'Removes the OSPF configuration',
        'router ldp' => 'Enters LDP configuration context', 
        'no router ldp' => 'Removes the LDP configuration',
        'router bgp' => 'Enters BGP configuration context (Requires: ASN)', 
        'no router bgp' => 'Removes the BGP configuration',
        'exit' => 'Exits configuration mode',
        'help' => 'Displays this help message',
    ],
    'config-if' => [
        'description' => 'Adds description to the interface',
        'no description' => 'Removes the description',
        'address' => 'Sets the IP address (CIDR format X.X.X.X/Y)',
        'no address' => 'Removes the IP address',
        'no shutdown' => 'Enables the interface',
        'shutdown' => 'Disables the interface',
        'exit' => 'Exits interface configuration',
        'help' => 'Displays this help message',
    ],
    'config-service-vpls' => [
        'description' => 'Adds description to the VPLS service',
        'no description' => 'Removes the description',
        'spoke-sdp' => 'Configures a spoke SDP (Ex: spoke-sdp 2:100 create)',
        'no spoke-sdp' => 'Removes a spoke SDP (Ex: no spoke-sdp 2:100)',
        'exit' => 'Exits VPLS service configuration',
        'help' => 'Displays this help message',
    ],
    'config-router-ospf' => [ 
        'area' => 'Defines the OSPF area (Ex: area 0.0.0.0)',
        'no area' => 'Resets the OSPF area to default',
        'interface' => 'Enables OSPF on an interface (Ex: interface 10.10.10.5)',
        'no interface' => 'Disables OSPF on an interface (Ex: no interface 10.10.10.5)',
        'exit' => 'Exits OSPF configuration',
        'help' => 'Displays this help message',
    ],
    'config-router-ldp' => [ 
        'interface' => 'Enables LDP on an interface (Ex: interface 1/1/1)',
        'no interface' => 'Disables LDP on an interface (Ex: no interface 1/1/1)',
        'exit' => 'Exits LDP configuration',
        'help' => 'Displays this help message',
    ],
    'config-router-bgp' => [ 
        'group' => 'Creates or selects a BGP peer group (Ex: group iBGP type internal)',
        'no group' => 'Removes a BGP peer group (Ex: no group iBGP)',
        'neighbor' => 'Configures a BGP neighbor (Ex: group iBGP neighbor 1.1.1.1 remote-as 65000)',
        'no neighbor' => 'Removes a BGP neighbor (Ex: no group iBGP neighbor 1.1.1.1)',
        'exit' => 'Exits BGP configuration',
        'help' => 'Displays this help message',
    ],
];

function get_suggestions($mode, $input) {
    global $commands;
    // Mapeamento de modos para chaves de comando
    $mode_map = [
        'config-if' => 'config-if',
        'config-service-vpls' => 'config-service-vpls',
        'config-router-ospf' => 'config-router-ospf',
        'config-router-ldp' => 'config-router-ldp',
        'config-router-bgp' => 'config-router-bgp',
    ];
    $mode_key = $mode_map[$mode] ?? $mode;
    
    if ($mode === 'password') return []; 

    $input = strtolower(trim($input));
    $suggestions = [];
    
    // Verifica se a entrada termina com '?' para ativar o modo help
    if (substr(trim($input), -1) === '?') { 
        $base_input = substr($input, 0, -1);
        if (isset($commands[$mode_key])) {
             foreach ($commands[$mode_key] as $cmd => $desc) {
                if (substr($cmd, 0, strlen($base_input)) === $base_input) {
                     $suggestions[] = $cmd . ' - ' . $desc;
                }
            }
        }
        
        if (empty($suggestions) && empty($base_input)) {
             $suggestions[] = "Available commands in '{$mode}' mode:"; // Traduzido
             if (isset($commands[$mode_key])) {
                 foreach ($commands[$mode_key] as $cmd => $desc) $suggestions[] = $cmd . ' - ' . $desc;
             }
        } elseif (empty($suggestions) && !empty($base_input)) {
            $suggestions[] = "% No command matches: {$base_input}"; // Traduzido
        }
    } else {
        // Autocompletar (Não usado no front-end, mas mantido)
        if (isset($commands[$mode_key])) {
            foreach ($commands[$mode_key] as $cmd => $desc) {
                 if (substr($cmd, 0, strlen($input)) === $input) {
                     $suggestions[] = $cmd;
                 }
            }
        }
    }
    return $suggestions;
}

// Função para obter a string de configuração OSPF
function get_ospf_config_string($ospf_config) {
    $output = [];
    $output[] = "router ospf {$ospf_config['id']}";
    $output[] = "  area {$ospf_config['area']}";
    if (!empty($ospf_config['interfaces'])) {
        foreach ($ospf_config['interfaces'] as $iface_ip) {
            $output[] = "  interface {$iface_ip}";
        }
    }
    $output[] = "exit";
    return $output;
}

// Função para obter a string de configuração LDP
function get_ldp_config_string($ldp_config) {
    $output = [];
    $output[] = "router ldp";
    if (!empty($ldp_config['interfaces'])) {
        foreach ($ldp_config['interfaces'] as $iface) {
            $output[] = "  interface {$iface}";
        }
    }
    $output[] = "exit";
    return $output;
}

// Função para obter a string de configuração BGP
function get_bgp_config_string($bgp_config) {
    $output = [];
    $output[] = "router bgp {$bgp_config['id']}";
    if (!empty($bgp_config['groups'])) {
        foreach ($bgp_config['groups'] as $group_name => $group_config) {
            $output[] = "  group {$group_name} type {$group_config['type']}";
            foreach ($group_config['neighbors'] as $neighbor_ip => $neighbor_config) {
                 $output[] = "    neighbor {$neighbor_ip} remote-as {$neighbor_config['remote-as']}";
            }
            $output[] = "  exit"; // exit do grupo
        }
    }
    $output[] = "exit";
    return $output;
}


// --- FUNÇÃO PARA TRATAR COMANDOS GLOBAIS ---

function handle_global_commands($input_lower, &$config, $configDir) {
    global $commands, $routerName;

    // 1. Comando 'help' (Global)
    if ($input_lower === 'help') {
        $mode_key = $config['mode'];
        
        // CORREÇÃO: Substituindo str_starts_with (PHP 8.0+) por strpos (Compatível)
        if (strpos($mode_key, 'config-if') === 0) $mode_key = 'config-if';
        if (strpos($mode_key, 'config-service-vpls') === 0) $mode_key = 'config-service-vpls';
        if (strpos($mode_key, 'config-router-ospf') === 0) $mode_key = 'config-router-ospf';
        if (strpos($mode_key, 'config-router-ldp') === 0) $mode_key = 'config-router-ldp';
        if (strpos($mode_key, 'config-router-bgp') === 0) $mode_key = 'config-router-bgp';
        
        add_output("Available commands in '{$config['mode']}' mode:"); // Traduzido
        
        if (isset($commands[$mode_key])) {
            foreach ($commands[$mode_key] as $cmd => $desc) {
                add_output("  " . str_pad($cmd, 20) . " - " . $desc);
            }
        }
        return true; 
    }

    // 2. Comando 'clear' (Global)
    if ($input_lower === 'clear') {
        $config['output'] = [];
        return true; 
    }

    // 3. Comando 'save' ou 'write' (Global)
    if ($input_lower === 'save' || $input_lower === 'write' || $input_lower === 'write memory') {
        $safeFileName = preg_replace('/[^a-zA-Z0-9_\-]/', '_', $config['name']);
        
        // Remove dados de sessão antes de salvar
        $configToSave = $config;
        unset($configToSave['output'], $configToSave['current_interface'], $configToSave['current_service'], $configToSave['current_protocol'], $configToSave['mode'], $configToSave['expecting_password']);
        
        $save_result = file_put_contents("$configDir/$safeFileName.json", json_encode($configToSave, JSON_PRETTY_PRINT));
        
        if ($save_result === false) {
            add_output("% ERROR: Failed to save configuration. Check 'configs' directory permissions."); // Traduzido
        } else {
            add_output("Building configuration..."); // Traduzido
            add_output("[OK]");
            add_output("Configuration saved to {$safeFileName}.json"); // Traduzido
        }
        return true; 
    }
    
    return false; 
}

// --- MANIPULADORES DE MODO ---

function handle_normal_mode($parsed, $input) {
    $secret = $_SESSION['config']['password_enable'] ?? '';
    $cmd = $parsed['command_lower'];
    
    if ($cmd === 'enable') {
        if (!empty($secret)) {
            $_SESSION['config']['mode'] = 'password';
            $_SESSION['config']['expecting_password'] = true;
            add_output("Password required."); // Traduzido
            return;
        }
        
        add_output("Entering privileged EXEC mode..."); // Traduzido
        $_SESSION['config']['mode'] = 'enable';

    } elseif ($cmd === 'exit') {
        session_destroy();
        add_output("Simulator session terminated. Please refresh the browser."); // Traduzido
    } else {
        add_output("% Unrecognized command in normal mode: " . htmlspecialchars($input)); // Traduzido
    }
}

function handle_password_mode($input) {
    $secret = $_SESSION['config']['password_enable'] ?? '';
    
    if ($input === $secret) {
        add_output("Authentication successful."); // Traduzido
        $_SESSION['config']['mode'] = 'enable';
    } else {
        add_output("% Invalid password"); // Traduzido
        $_SESSION['config']['mode'] = 'normal'; 
    }
    
    $_SESSION['config']['expecting_password'] = false; 
}

function handle_enable_mode($parsed, $input) {
    global $routerName;
    $cmd = $parsed['command_lower'];
    $args_lower = $parsed['args_lower'];

    if ($cmd === 'configure') {
        add_output("Entering configuration mode..."); // Traduzido
        $_SESSION['config']['mode'] = 'configure';
    } elseif ($cmd === 'show') {
        $show_target = implode(' ', $args_lower);
        
        if ($show_target === 'configuration') {
            add_output("Configuration for Router: " . strtoupper($_SESSION['config']['name']));
            add_output("--- GLOBAL ---");
            add_output("hostname " . $_SESSION['config']['name']);
            
            $secret = ($_SESSION['config']['password_enable'] ?? false) ? '7 <hidden>' : 'NOT SET';
            add_output("enable secret {$secret}");
            
            $gateway = $_SESSION['config']['default_gateway'] ?? 'NOT SET';
            if ($gateway !== 'NOT SET') {
                 add_output("ip default-gateway {$gateway}");
            }
            
            // Exibe Protocolos (OSPF)
            if(isset($_SESSION['config']['protocols']['ospf']) && $_SESSION['config']['protocols']['ospf']['id'] !== null) {
                add_output("--- PROTOCOL OSPF ---");
                foreach (get_ospf_config_string($_SESSION['config']['protocols']['ospf']) as $line) {
                    add_output($line);
                }
            }
            
            // Exibe Protocolos (LDP)
            if(isset($_SESSION['config']['protocols']['ldp']) && !empty($_SESSION['config']['protocols']['ldp']['interfaces'])) {
                add_output("--- PROTOCOL LDP ---");
                foreach (get_ldp_config_string($_SESSION['config']['protocols']['ldp']) as $line) {
                    add_output($line);
                }
            }
            
            // Exibe Protocolos (BGP)
            if(isset($_SESSION['config']['protocols']['bgp']) && $_SESSION['config']['protocols']['bgp']['id'] !== null) {
                add_output("--- PROTOCOL BGP ---");
                foreach (get_bgp_config_string($_SESSION['config']['protocols']['bgp']) as $line) {
                    add_output($line);
                }
            }

            // Exibe Serviços VPLS
            if(!empty($_SESSION['config']['services']['vpls'])) {
                add_output("--- SERVICES VPLS ---");
                foreach ($_SESSION['config']['services']['vpls'] as $id => $service) {
                    $desc = $service['description'] ?? 'No description';
                    add_output("service vpls {$id} customer {$service['customer_id']} create");
                    add_output("  description \"{$desc}\"");
                    // Adicionar spoke-sdps aqui se desejado
                    if (!empty($service['spoke_sdp'])) {
                        foreach ($service['spoke_sdp'] as $sdp) {
                             add_output("  spoke-sdp {$sdp} vc-type mpls create");
                        }
                    }
                    add_output("exit");
                }
            }

            // Exibe Interfaces
            $all_interfaces = array_merge($_SESSION['config']['interfaces'], $_SESSION['config']['loopbacks']);
            if(!empty($all_interfaces)) {
                add_output("--- INTERFACES ---");
                foreach ($all_interfaces as $name => $iface) {
                    $ip = $iface['address'] ?? 'unassigned';
                    $desc = $iface['description'] ?? 'No description';
                    if (strpos($name, 'LOOPBACK') !== false) {
                        $loop_id = substr($name, 8); 
                        add_output("interface loopback {$loop_id}");
                    } else {
                        add_output("interface $name");
                    }
                    add_output("  description \"{$desc}\"");
                    if (!empty($iface['address'])) {
                        add_output("  address {$ip}");
                    }
                    if ($iface['shutdown']) { add_output("  shutdown"); }
                    add_output("exit");
                }
            }
        } elseif ($show_target === 'version') {
            $uptime = $_SESSION['config']['uptime'] ?? generate_uptime(); 
            add_output("{$routerName} OS 15.0(1)M1"); 
            add_output("Software Version: 7250 IXR-e Release 24.5"); 
            add_output("Uptime is {$uptime}"); 
            $_SESSION['config']['uptime'] = $uptime;
        } 
         elseif ($show_target === 'interfaces') {
            $all_interfaces = array_merge($_SESSION['config']['interfaces'], $_SESSION['config']['loopbacks']);
            if (empty($all_interfaces)) { 
                add_output("No interfaces configured."); // Traduzido
            } else { 
                add_output(str_pad("Interface", 15) . str_pad("IP Address", 20) . str_pad("Status", 10) . "Description");
                add_output(str_repeat("-", 58));
                foreach ($all_interfaces as $name => $iface) { 
                    $desc = $iface['description'] ?? 'n/a'; 
                    // Se a interface não foi explicitamente desligada e tem IP, considere UP
                    $status = ($iface['shutdown'] === false && $iface['address']) ? 'UP' : 'DOWN'; 
                    $ip = $iface['address'] ?? 'unassigned'; 
                    add_output(str_pad($name, 15) . str_pad($ip, 20) . str_pad($status, 10) . $desc);
                } 
            }
        } elseif ($show_target === 'services') {
             if(!empty($_SESSION['config']['services']['vpls'])) {
                add_output("Active VPLS Services:"); // Traduzido
                add_output("ID | Customer | Description");
                add_output("---|---|---");
                foreach ($_SESSION['config']['services']['vpls'] as $id => $service) {
                    $desc = $service['description'] ?? 'No description';
                    add_output("{$id} | {$service['customer_id']} | {$desc}");
                    if (!empty($service['spoke_sdp'])) {
                        add_output("  - Spoke SDPs: " . implode(', ', $service['spoke_sdp']));
                    }
                }
             } else {
                 add_output("No active VPLS services configured."); // Traduzido
             }
        } elseif ($show_target === 'clock') {
             add_output("Current time is " . date('H:i:s T') . " " . date('D M j Y')); // Traduzido
        } elseif ($show_target === 'ip route') {
             add_output("IP Route Table (Simulated)");
             add_output(str_repeat("=", 40));
             
             // 1. Rotas Locais (Interface)
             $all_interfaces = array_merge($_SESSION['config']['interfaces'], $_SESSION['config']['loopbacks']);
             foreach ($all_interfaces as $name => $iface) {
                 if (!empty($iface['address']) && $iface['shutdown'] === false) {
                    // Exemplo: C 192.168.1.0/24 is directly connected, GigabitEthernet1/1
                    $network = $iface['address']; 
                    add_output("C {$network} is directly connected, {$name}"); 
                 }
             }
             
             // 2. Rotas OSPF (Se configurado)
             $ospf_config = $_SESSION['config']['protocols']['ospf'] ?? null;
             if ($ospf_config && !empty($ospf_config['interfaces'])) {
                 add_output("O * LSA routes are learned through OSPF Protocol");
             }
             
             // 3. Gateway Padrão
             $gateway = $_SESSION['config']['default_gateway'] ?? null;
             if ($gateway) {
                 add_output("S* 0.0.0.0/0 [1/0] via {$gateway}");
             }
             
             if (empty($all_interfaces) && empty($gateway) && empty($ospf_config)) {
                 add_output("Route table is empty.");
             }
        } else {
            add_output("Unknown 'show' command or arguments."); // Traduzido
        }
    } elseif ($cmd === 'ping' && isset($args_lower[0])) {
        $ip_address = $args_lower[0]; 
        add_output("Sending 5, 100-byte ICMP Echos to {$ip_address}:"); // Traduzido
        add_output("!!!!!"); 
    } elseif ($cmd === 'exit') {
        add_output("Exiting privileged EXEC mode..."); // Traduzido
        $_SESSION['config']['mode'] = 'normal';
    } elseif ($cmd === 'reload') {
        add_output("The system is preparing to reload. The session will be reset."); // Traduzido
        session_destroy();
    } else {
        add_output("Unrecognized command in enable mode: " . htmlspecialchars($input)); // Traduzido
    }
}

function handle_configure_mode($parsed, $input) {
    $cmd = $parsed['command_lower'];
    $args_lower = $parsed['args_lower'];
    $raw_args = $parsed['raw_args'];
    
    // --- NO COMMANDS (Remoção de Entidades Principais) ---
    if ($cmd === 'no') {
        $no_cmd_full = $raw_args;
        $no_args = preg_split('/\s+/', strtolower($no_cmd_full));
        
        // 1. NO HOSTNAME (Resetar)
        if (strtolower($no_cmd_full) === 'hostname') {
             $_SESSION['config']['name'] = 'NOKIA CLI';
             add_output("Hostname reset to NOKIA CLI.");
        // 2. NO ENABLE SECRET (Limpar senha)
        } elseif (strtolower($no_cmd_full) === 'enable secret') {
             $_SESSION['config']['password_enable'] = '';
             add_output("Enable secret cleared.");
        // 3. NO IP DEFAULT-GATEWAY (Limpar default gateway)
        } elseif (strtolower($no_cmd_full) === 'ip default-gateway') {
             $_SESSION['config']['default_gateway'] = null;
             add_output("Default gateway cleared.");
        // 4. NO INTERFACE <name> / NO INTERFACE LOOPBACK <id>
        } elseif ($no_args[0] === 'interface' && isset($no_args[1])) {
            $is_loopback = $no_args[1] === 'loopback';
            $iface_array_key = $is_loopback ? 'loopbacks' : 'interfaces';
            $iface_name = $is_loopback ? 
                            "LOOPBACK" . strtoupper(trim($no_args[2] ?? '')) : 
                            strtoupper(trim($no_args[1]));

            if (isset($_SESSION['config'][$iface_array_key][$iface_name])) {
                unset($_SESSION['config'][$iface_array_key][$iface_name]);
                add_output("$iface_name removed from configuration.");
            } else {
                add_output("% Error: Interface $iface_name does not exist.");
            }
        // 5. NO SERVICE VPLS <id>
        } elseif ($no_args[0] === 'service' && ($no_args[1] ?? '') === 'vpls' && isset($no_args[2])) {
            $vpls_id = (int) $no_args[2];
            if (isset($_SESSION['config']['services']['vpls'][$vpls_id])) {
                unset($_SESSION['config']['services']['vpls'][$vpls_id]);
                add_output("Service VPLS $vpls_id removed.");
            } else {
                add_output("% Error: Service VPLS $vpls_id does not exist.");
            }
        // 6. NO ROUTER OSPF / NO ROUTER LDP / NO ROUTER BGP
        } elseif ($no_args[0] === 'router' && isset($no_args[1])) {
            $protocol_name = $no_args[1];
            if ($protocol_name === 'ospf') {
                 $_SESSION['config']['protocols']['ospf'] = ['id' => null, 'area' => null, 'interfaces' => []];
                 add_output("OSPF router configuration removed.");
            } elseif ($protocol_name === 'ldp') {
                 $_SESSION['config']['protocols']['ldp'] = ['interfaces' => []];
                 add_output("LDP router configuration removed.");
            } elseif ($protocol_name === 'bgp') {
                 $_SESSION['config']['protocols']['bgp'] = ['id' => null, 'groups' => []];
                 add_output("BGP router configuration removed.");
            } else {
                 add_output("% Error: Unknown router protocol '{$protocol_name}' to remove.");
            }
        } else {
             add_output("Unknown 'no' command in configure mode: " . htmlspecialchars($input));
        }
        return; 
    }
    
    // --- COMANDOS DE CRIAÇÃO/CONFIGURAÇÃO ---

    // 1. HOSTNAME
    if ($cmd === 'hostname' && !empty($raw_args)) {
        $newName = trim($raw_args); 
        if (strpos($newName, '"') === 0 && substr($newName, -1) === '"') {
            $newName = trim($newName, '"');
        }
        $newName = strtoupper($newName); 
        $_SESSION['config']['name'] = $newName; 
        add_output("Hostname set to '{$newName}'"); 
        return;
    } 
    
    // 2. ENABLE SECRET
    $parts_secret = preg_split('/\s+/', $raw_args, 2); 
    if ($cmd === 'enable' && ($args_lower[0] ?? '') === 'secret' && isset($parts_secret[1])) {
        $secretValue = trim($parts_secret[1]); 
        $_SESSION['config']['password_enable'] = $secretValue; 
        add_output("Enable secret set."); 
        return;
    }
    
    // 3. IP DEFAULT-GATEWAY
    if ($cmd === 'ip' && ($args_lower[0] ?? '') === 'default-gateway' && isset($args_lower[1])) {
        $gateway_ip = trim($args_lower[1]); 
        if (!filter_var($gateway_ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            add_output("% Error: Invalid IP address format."); 
            return;
        }
        $_SESSION['config']['default_gateway'] = $gateway_ip; 
        add_output("Default gateway set to {$gateway_ip}"); 
        return;
    }
    
    // 4. INTERFACE (Física ou Loopback)
    $iface_args_parts = preg_split('/\s+/', $raw_args, 2);

    if ($cmd === 'interface' && isset($args_lower[0])) {
        $is_loopback = $args_lower[0] === 'loopback';
        
        if ($is_loopback && isset($args_lower[1])) {
            $int_name_raw = $iface_args_parts[1] ?? $args_lower[1];
            $int_name = "LOOPBACK" . strtoupper(trim($int_name_raw));
            $default_data = ['description' => null, 'address' => null, 'shutdown' => false];
            $_SESSION['config']['loopbacks'][$int_name] = $_SESSION['config']['loopbacks'][$int_name] ?? $default_data;
        } elseif (!$is_loopback) {
            $int_name = strtoupper(trim($iface_args_parts[0])); 
            $default_data = ['description' => null, 'port' => null, 'address' => null, 'lan' => null, 'shutdown' => true];
            $_SESSION['config']['interfaces'][$int_name] = $_SESSION['config']['interfaces'][$int_name] ?? $default_data;
        } else {
            add_output("Error: Incomplete interface command."); 
            return;
        }
        
        $_SESSION['config']['current_interface'] = $int_name;
        $_SESSION['config']['current_service'] = null; 
        $_SESSION['config']['current_protocol'] = null; 
        add_output("Configuring interface $int_name"); 
        $_SESSION['config']['mode'] = 'config-if'; 
        return;
    }
    
    // 5. SERVICE VPLS
    $service_match = preg_match('/^service\s+vpls\s+(\d+)\s+customer\s+(\d+)\s+create$/i', $input, $matches);
    
    if ($service_match) {
        $vpls_id = (int)$matches[1];
        $customer_id = (int)$matches[2];
        $service_name = "VPLS{$vpls_id}";

        if (!isset($_SESSION['config']['services']['vpls'])) $_SESSION['config']['services']['vpls'] = [];

        $_SESSION['config']['services']['vpls'][$vpls_id] = $_SESSION['config']['services']['vpls'][$vpls_id] ?? [
            'id' => $vpls_id,
            'customer_id' => $customer_id,
            'description' => null,
            'spoke_sdp' => [],
        ];
        
        $_SESSION['config']['current_service'] = $service_name;
        $_SESSION['config']['current_interface'] = null; 
        $_SESSION['config']['current_protocol'] = null;
        add_output("Entering Service VPLS $vpls_id context (Customer $customer_id)"); 
        $_SESSION['config']['mode'] = 'config-service-vpls';
        return;
    }
    
    // 6. ROUTER OSPF
    $ospf_match = preg_match('/^router\s+ospf\s+(\d+)$/i', $input, $matches);
    
    if ($ospf_match) {
        $ospf_id = (int)$matches[1];
        $protocol_name = "OSPF{$ospf_id}";
        
        $_SESSION['config']['protocols']['ospf'] = $_SESSION['config']['protocols']['ospf'] ?? ['id' => $ospf_id, 'area' => '0.0.0.0', 'interfaces' => []];
        
        $_SESSION['config']['current_protocol'] = $protocol_name;
        $_SESSION['config']['current_service'] = null;
        $_SESSION['config']['current_interface'] = null;
        add_output("Entering OSPF Protocol $ospf_id context"); 
        $_SESSION['config']['mode'] = 'config-router-ospf';
        return;
    }
    
    // 7. ROUTER LDP
    if ($cmd === 'router' && ($args_lower[0] ?? '') === 'ldp') {
        $protocol_name = "LDP";
        
        $_SESSION['config']['protocols']['ldp'] = $_SESSION['config']['protocols']['ldp'] ?? ['interfaces' => []];
        
        $_SESSION['config']['current_protocol'] = $protocol_name;
        $_SESSION['config']['current_service'] = null;
        $_SESSION['config']['current_interface'] = null;
        add_output("Entering LDP Protocol context"); 
        $_SESSION['config']['mode'] = 'config-router-ldp';
        return;
    }
    
    // 8. ROUTER BGP 
    $bgp_match = preg_match('/^router\s+bgp\s+(\d+)$/i', $input, $matches);
    
    if ($bgp_match) {
        $bgp_id = (int)$matches[1];
        $protocol_name = "BGP{$bgp_id}";
        
        $_SESSION['config']['protocols']['bgp'] = $_SESSION['config']['protocols']['bgp'] ?? ['id' => $bgp_id, 'groups' => []];
        
        $_SESSION['config']['current_protocol'] = $protocol_name;
        $_SESSION['config']['current_service'] = null;
        $_SESSION['config']['current_interface'] = null;
        add_output("Entering BGP Protocol $bgp_id context"); 
        $_SESSION['config']['mode'] = 'config-router-bgp';
        return;
    }

    if ($cmd === 'exit') {
        add_output("Exiting configuration mode..."); 
        $_SESSION['config']['mode'] = 'enable';
    } else {
        add_output("Unknown or incomplete command in configure mode: " . htmlspecialchars($input)); 
    }
}

function handle_config_if_mode($parsed, $input) {
    $iface_name = get_current_interface_name();
    if (empty($iface_name)) {
        add_output("% Error: No interface selected. Exiting interface configuration."); // Traduzido
        $_SESSION['config']['mode'] = 'configure';
        return;
    }

    $is_loopback = strpos($iface_name, 'LOOPBACK') !== false;
    $iface_array_key = $is_loopback ? 'loopbacks' : 'interfaces';
    
    $cmd_lower = strtolower(trim($input));
    $args_lower = $parsed['args_lower'];
    
    if ($cmd_lower === 'exit') {
        add_output("Exiting interface configuration..."); // Traduzido
        $_SESSION['config']['current_interface'] = null;
        $_SESSION['config']['mode'] = 'configure';
    
    // --- NO COMMANDS (Negação/Remoção em Interface) ---
    } elseif ($parsed['command_lower'] === 'no') {
        $no_cmd = strtolower($parsed['raw_args']); 
        
        if ($no_cmd === 'description') {
            $_SESSION['config'][$iface_array_key][$iface_name]['description'] = null;
            add_output("Description removed from $iface_name.");
        } elseif ($no_cmd === 'address') {
            $_SESSION['config'][$iface_array_key][$iface_name]['address'] = null;
            add_output("Address removed from $iface_name.");
        } elseif ($no_cmd === 'shutdown') {
            $_SESSION['config'][$iface_array_key][$iface_name]['shutdown'] = false;
            add_output("$iface_name enabled (no shutdown).");
        } else {
            add_output("Unknown 'no' command in interface mode: " . htmlspecialchars($input));
        }
        return; 
    
    // --- COMANDOS DE CRIAÇÃO/CONFIGURAÇÃO ---
    } elseif (preg_match('/^description\s+(.*)/i', $input, $matches)) {
        $desc = trim($matches[1]);
        if (strpos($desc, '"') === 0 && substr($desc, -1) === '"') {
            $desc = trim($desc, '"');
        }
        $_SESSION['config'][$iface_array_key][$iface_name]['description'] = $desc; 
        add_output("Description set for $iface_name: '{$desc}'"); 
    } elseif ($parsed['command_lower'] === 'address' && isset($args_lower[0])) {
        // Aceita o IP + Máscara (e.g., 192.168.1.1/24)
        $ip_address_mask = trim($args_lower[0]);
        if (!preg_match('/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\/\d{1,2}$/', $ip_address_mask)) {
            add_output("% Error: Invalid IP address format (CIDR). Use X.X.X.X/Y."); 
            return;
        }
        $_SESSION['config'][$iface_array_key][$iface_name]['address'] = $ip_address_mask; 
        add_output("Address set for $iface_name: $ip_address_mask"); 
    } elseif ($cmd_lower === 'no shutdown') { // Mantido por convenção
        $_SESSION['config'][$iface_array_key][$iface_name]['shutdown'] = false; 
        add_output("$iface_name enabled"); 
    } elseif ($cmd_lower === 'shutdown') {
        $_SESSION['config'][$iface_array_key][$iface_name]['shutdown'] = true; 
        add_output("$iface_name disabled"); 
    } else {
        add_output("Unknown command in interface mode: " . htmlspecialchars($input)); 
    }
}

// Manipulador para o modo de Configuração de Serviço VPLS
function handle_config_service_vpls_mode($parsed, $input) {
    $service_name = $_SESSION['config']['current_service']; 
    $vpls_id = (int) substr($service_name, 4); 
    
    if (!isset($_SESSION['config']['services']['vpls'][$vpls_id])) {
        add_output("% Error: VPLS service not found. Exiting service configuration."); // Traduzido
        $_SESSION['config']['current_service'] = null;
        $_SESSION['config']['mode'] = 'configure';
        return;
    }
    
    $cmd_lower = strtolower(trim($input));

    if ($cmd_lower === 'exit') {
        add_output("Exiting Service VPLS $vpls_id configuration..."); // Traduzido
        $_SESSION['config']['current_service'] = null;
        $_SESSION['config']['mode'] = 'configure';
        
    // --- NO COMMANDS (Negação/Remoção em VPLS) ---
    } elseif ($parsed['command_lower'] === 'no') {
        $no_cmd_full = strtolower($parsed['raw_args']);
        
        if ($no_cmd_full === 'description') {
            $_SESSION['config']['services']['vpls'][$vpls_id]['description'] = null;
            add_output("Description removed from VPLS $vpls_id.");
        } elseif (preg_match('/^spoke-sdp\s+(\d+:\d+)$/i', $no_cmd_full, $matches)) {
            $sdp_to_remove = $matches[1];
            
            $key = array_search($sdp_to_remove, $_SESSION['config']['services']['vpls'][$vpls_id]['spoke_sdp']);
            if ($key !== false) {
                unset($_SESSION['config']['services']['vpls'][$vpls_id]['spoke_sdp'][$key]);
                $_SESSION['config']['services']['vpls'][$vpls_id]['spoke_sdp'] = array_values($_SESSION['config']['services']['vpls'][$vpls_id]['spoke_sdp']);
                add_output("Spoke SDP $sdp_to_remove removed from VPLS $vpls_id.");
            } else {
                add_output("% Error: Spoke SDP $sdp_to_remove is not configured in VPLS $vpls_id.");
            }
        } else {
            add_output("Unknown 'no' command in VPLS mode: " . htmlspecialchars($input)); 
        }
        return;
        
    // --- COMANDOS DE CRIAÇÃO/CONFIGURAÇÃO ---
    } elseif (preg_match('/^description\s+(.*)/i', $input, $matches)) {
        $desc = trim($matches[1]);
        if (strpos($desc, '"') === 0 && substr($desc, -1) === '"') {
            $desc = trim($desc, '"');
        }
        $_SESSION['config']['services']['vpls'][$vpls_id]['description'] = $desc; 
        add_output("Description set for VPLS $vpls_id: '{$desc}'"); 
    } elseif (preg_match('/^spoke-sdp\s+(\d+:\d+)\s+vc-type\s+mpls\s+create$/i', $input, $matches)) {
        $sdp_id = $matches[1];
        if (!in_array($sdp_id, $_SESSION['config']['services']['vpls'][$vpls_id]['spoke_sdp'])) {
             $_SESSION['config']['services']['vpls'][$vpls_id]['spoke_sdp'][] = $sdp_id;
             add_output("Spoke SDP $sdp_id added to VPLS $vpls_id."); 
        } else {
             add_output("Spoke SDP $sdp_id already exists in VPLS $vpls_id."); 
        }
    } else {
        add_output("Unknown command in VPLS mode: " . htmlspecialchars($input)); 
    }
}

// Manipulador para o modo de Configuração OSPF
function handle_config_router_ospf_mode($parsed, $input) {
    $protocol_name = $_SESSION['config']['current_protocol']; 
    $ospf_id = (int) substr($protocol_name, 4); 
    
    $cmd_lower = strtolower(trim($input));
    
    if ($cmd_lower === 'exit') {
        add_output("Exiting OSPF configuration..."); 
        $_SESSION['config']['current_protocol'] = null;
        $_SESSION['config']['mode'] = 'configure';
        
    // --- NO COMMANDS (Negação/Remoção em OSPF) ---
    } elseif ($parsed['command_lower'] === 'no') {
        $no_cmd_full = strtolower($parsed['raw_args']); 
        
        if ($no_cmd_full === 'area') {
            $_SESSION['config']['protocols']['ospf']['area'] = '0.0.0.0';
            add_output("OSPF Area configuration reset (default is 0.0.0.0).");
        } elseif (preg_match('/^interface\s+(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})$/i', $no_cmd_full, $matches)) {
            $ip_to_remove = $matches[1];
            
            $key = array_search($ip_to_remove, $_SESSION['config']['protocols']['ospf']['interfaces']);
            if ($key !== false) {
                unset($_SESSION['config']['protocols']['ospf']['interfaces'][$key]);
                $_SESSION['config']['protocols']['ospf']['interfaces'] = array_values($_SESSION['config']['protocols']['ospf']['interfaces']);
                add_output("Interface IP $ip_to_remove removed from OSPF.");
            } else {
                add_output("% Error: Interface IP $ip_to_remove is not configured in OSPF.");
            }
        } else {
            add_output("Unknown 'no' command in OSPF mode: " . htmlspecialchars($input)); 
        }
        return;
        
    // --- COMANDOS DE CRIAÇÃO/CONFIGURAÇÃO ---
    } elseif (preg_match('/^area\s+(.*)$/i', $input, $matches)) {
        $area_id = trim($matches[1]);
        if (!preg_match('/^(\d{1,3}\.){3}\d{1,3}$/', $area_id)) {
             add_output("% Error: Invalid Area ID format. Use X.X.X.X."); 
             return;
        }
        $_SESSION['config']['protocols']['ospf']['area'] = $area_id;
        add_output("OSPF Area set to $area_id."); 
    } elseif (preg_match('/^interface\s+(.*)$/i', $input, $matches)) {
        $iface_ip = trim($matches[1]);
        
        // 1. Validação do formato IP
        if (!preg_match('/^(\d{1,3}\.){3}\d{1,3}$/', $iface_ip)) {
             add_output("% Error: Invalid IP address format. Use X.X.X.X (must match an interface primary address).");
             return;
        }

        // 2. Validação: Checar se o IP existe em alguma interface configurada
        $all_interfaces = array_merge($_SESSION['config']['interfaces'], $_SESSION['config']['loopbacks']);
        $ip_exists = false;
        foreach ($all_interfaces as $iface) {
            if (strpos($iface['address'] ?? '', $iface_ip . '/') === 0) {
                $ip_exists = true;
                break;
            }
        }
        
        if (!$ip_exists) {
            add_output("% Error: The IP address '{$iface_ip}' is not configured as the primary address on any interface.");
            return;
        }
        
        // 3. Adição (se válido)
        if (!in_array($iface_ip, $_SESSION['config']['protocols']['ospf']['interfaces'])) {
            $_SESSION['config']['protocols']['ospf']['interfaces'][] = $iface_ip;
            add_output("Interface IP $iface_ip added to OSPF.");
        } else {
            add_output("Interface IP $iface_ip is already configured in OSPF.");
        }
    } else {
        add_output("Unknown command in OSPF mode: " . htmlspecialchars($input)); 
    }
}

// Manipulador para o modo de Configuração LDP
function handle_config_router_ldp_mode($parsed, $input) {
    $cmd_lower = strtolower(trim($input));
    $args = $parsed['args_lower'];
    
    if ($cmd_lower === 'exit') {
        add_output("Exiting LDP configuration..."); 
        $_SESSION['config']['current_protocol'] = null;
        $_SESSION['config']['mode'] = 'configure';
        
    // --- NO COMMANDS (Negação/Remoção em LDP) ---
    } elseif ($parsed['command_lower'] === 'no') {
        $no_cmd_full = strtolower($parsed['raw_args']); 
        
        if (preg_match('/^interface\s+([a-zA-Z0-9\-\/]+)$/i', $no_cmd_full, $matches)) {
            $iface_to_remove = strtoupper($matches[1]);
            
            $key = array_search($iface_to_remove, $_SESSION['config']['protocols']['ldp']['interfaces']);
            if ($key !== false) {
                unset($_SESSION['config']['protocols']['ldp']['interfaces'][$key]);
                $_SESSION['config']['protocols']['ldp']['interfaces'] = array_values($_SESSION['config']['protocols']['ldp']['interfaces']);
                add_output("LDP disabled on interface $iface_to_remove.");
            } else {
                add_output("% Error: LDP is not enabled on interface $iface_to_remove.");
            }
        } else {
            add_output("Unknown 'no' command in LDP mode: " . htmlspecialchars($input)); 
        }
        return;
        
    // --- COMANDOS DE CRIAÇÃO/CONFIGURAÇÃO ---
    } elseif ($parsed['command_lower'] === 'interface' && isset($args[0])) {
        $iface_name = strtoupper(trim($args[0]));
        $all_interfaces = array_keys($_SESSION['config']['interfaces']);
        $all_loopbacks = array_keys($_SESSION['config']['loopbacks']);
        
        // 1. Validação: Checar se o nome da interface existe (Lógica Existente)
        if (in_array($iface_name, $all_interfaces) || in_array($iface_name, $all_loopbacks)) {
             
             // --- VALIDAÇÃO DE PRÉ-REQUISITO LDP/OSPF ---
             $ospf_config = $_SESSION['config']['protocols']['ospf'] ?? null;
             
             if (!$ospf_config || $ospf_config['id'] === null) {
                  add_output("% Error: LDP requires OSPF to be enabled (router ospf <id>) before configuring interfaces.");
                  return; 
             }
             // --- FIM DA VALIDAÇÃO DE PRÉ-REQUISITO LDP/OSPF ---

             // 2. Adição (se válido)
             if (!in_array($iface_name, $_SESSION['config']['protocols']['ldp']['interfaces'])) {
                $_SESSION['config']['protocols']['ldp']['interfaces'][] = $iface_name;
                add_output("LDP enabled on interface $iface_name."); 
             } else {
                add_output("LDP is already enabled on interface $iface_name."); 
             }
        } else {
            add_output("% Error: Interface **{$iface_name}** does not exist or is not configured. Create it first.");
        }
    } else {
        add_output("Unknown command in LDP mode: " . htmlspecialchars($input)); 
    }
}

// Manipulador para o modo de Configuração BGP
function handle_config_router_bgp_mode($parsed, $input) {
    $bgp_config = &$_SESSION['config']['protocols']['bgp'];
    $cmd = $parsed['command_lower'];
    $raw_args = $parsed['raw_args'];
    
    if ($cmd === 'exit') {
        add_output("Exiting BGP configuration..."); 
        $_SESSION['config']['current_protocol'] = null;
        $_SESSION['config']['mode'] = 'configure';
        
    // --- NO COMMANDS (Negação/Remoção em BGP) ---
    } elseif ($cmd === 'no') {
        $no_cmd_full = $parsed['raw_args'];
        
        // 1. Comando 'no group <name>'
        if (preg_match('/^group\s+([a-zA-Z0-9\-]+)$/i', $no_cmd_full, $matches)) {
            $group_name = strtoupper($matches[1]);
            
            if (isset($bgp_config['groups'][$group_name])) {
                unset($bgp_config['groups'][$group_name]);
                add_output("BGP group $group_name removed.");
            } else {
                add_output("% Error: BGP group $group_name does not exist.");
            }
        // 2. Comando 'no group <name> neighbor <ip>'
        } elseif (preg_match('/^group\s+([a-zA-Z0-9\-]+)\s+neighbor\s+(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})$/i', $no_cmd_full, $matches)) {
            $group_name = strtoupper($matches[1]);
            $neighbor_ip = $matches[2];
            
            if (!isset($bgp_config['groups'][$group_name])) {
                 add_output("% Error: BGP group $group_name does not exist.");
            } elseif (isset($bgp_config['groups'][$group_name]['neighbors'][$neighbor_ip])) {
                 unset($bgp_config['groups'][$group_name]['neighbors'][$neighbor_ip]);
                 add_output("Neighbor $neighbor_ip removed from group $group_name.");
            } else {
                 add_output("% Error: Neighbor $neighbor_ip is not configured in group $group_name.");
            }
        } else {
            add_output("Unknown 'no' command in BGP mode: " . htmlspecialchars($input));
        }
        return; 
        
    // --- COMANDOS DE CRIAÇÃO/CONFIGURAÇÃO ---
    } elseif (preg_match('/^group\s+([a-zA-Z0-9\-]+)\s+type\s+(internal|external)$/i', $input, $matches)) {
        $group_name = strtoupper($matches[1]);
        $group_type = strtolower($matches[2]);
        
        $bgp_config['groups'][$group_name] = $bgp_config['groups'][$group_name] ?? [
            'type' => $group_type,
            'neighbors' => [],
        ];
        // Garante que o tipo seja atualizado se o grupo já existir
        $bgp_config['groups'][$group_name]['type'] = $group_type;
        add_output("BGP group $group_name created/updated with type $group_type."); 
    } elseif (preg_match('/^group\s+([a-zA-Z0-9\-]+)\s+neighbor\s+(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\s+remote-as\s+(\d+)$/i', $input, $matches)) {
        $group_name = strtoupper($matches[1]);
        $neighbor_ip = $matches[2];
        $remote_as = (int)$matches[3];
        
        if (!isset($bgp_config['groups'][$group_name])) {
            add_output("% Error: BGP group $group_name does not exist. Create the group first."); 
            return;
        }
        
        $bgp_config['groups'][$group_name]['neighbors'][$neighbor_ip] = [
            'remote-as' => $remote_as,
        ];
        add_output("Neighbor $neighbor_ip added to group $group_name with remote AS $remote_as."); 
    } 
    // --- VALIDAÇÃO DE CONTEXTO BGP ---
    elseif (strpos($cmd, 'neighbor') !== false) {
        add_output("% Error: Incomplete or ambiguous command. Use: group <name> neighbor <ip> remote-as <asn>");
    } 
    // --- FIM DA VALIDAÇÃO DE CONTEXTO BGP ---
    else {
        add_output("Unknown command in BGP mode: " . htmlspecialchars($input)); 
    }
}


// --- INICIALIZAÇÃO E FLUXO PRINCIPAL ---

// Configuração inicial da sessão se não existir
if (!isset($_SESSION['config'])) {
    $_SESSION['config'] = [
        'name' => 'NOKIA CLI',
        'interfaces' => [], 'loopbacks' => [], 
        'services' => ['vpls' => []],
        // Inicialização de protocolos com BGP
        'protocols' => [
            'ospf' => ['id' => null, 'area' => null, 'interfaces' => []], 
            'ldp' => ['interfaces' => []],
            'bgp' => ['id' => null, 'groups' => []], 
        ],
        'password_enable' => 'admin123', 
        'default_gateway' => null, 
        'mode' => 'normal',
        'current_interface' => null,
        'current_service' => null,
        'current_protocol' => null,
        'uptime' => generate_uptime(), 
        'output' => [], 
        'expecting_password' => false,
    ];
}

// 1. Definições de Entrada
$routerName = empty($_SESSION['config']['name']) ? 'NOKIA CLI' : strtoupper($_SESSION['config']['name']); 
$input = trim(isset($_POST['command']) ? $_POST['command'] : '');
$action = isset($_POST['action']) ? $_POST['action'] : 'command';
$currentMode = $_SESSION['config']['mode'];
$isPasswordAttempt = isset($_POST['is_password_attempt']) ? $_POST['is_password_attempt'] : false;
$contextName = get_current_context_name(); 

// 2. Manipulador de Sugestões (ACTION = SUGGEST)
if ($action === 'suggest') {
    $suggestions = get_suggestions($currentMode, isset($_POST['input']) ? $_POST['input'] : '');
    header('Content-Type: application/json');
    echo json_encode(['suggestions' => $suggestions]);
    exit;
}

// 3. Manipulador de Comandos (ACTION = COMMAND)
if ($action === 'command') {
    $input_lower = strtolower($input);
    $parsed_command = parse_router_command($input);

    // Lógica de tentativa de senha
    if ($currentMode === 'password' && $isPasswordAttempt) {
        handle_password_mode($input);
    } elseif (!empty($input)) {
        
        // ********************************************
        // * REMOÇÃO DO COMANDO REPETIDO (AJUSTE FINAL) *
        // ********************************************
        // A linha que repetia o comando (get_prompt_string + input) foi removida daqui.
        // O seu frontend (JavaScript) é agora responsável por exibir o comando digitado.

        // Tenta tratar comandos globais (save, clear, help)
        if (handle_global_commands($input_lower, $_SESSION['config'], $configDir)) {
            // Comando global tratado.
        } else {
            // Roteia para a função de modo apropriada
            switch ($_SESSION['config']['mode']) {
                case 'normal':
                    handle_normal_mode($parsed_command, $input);
                    break;
                case 'enable':
                    handle_enable_mode($parsed_command, $input);
                    break;
                case 'configure':
                    handle_configure_mode($parsed_command, $input);
                    break;
                case 'config-if':
                    handle_config_if_mode($parsed_command, $input);
                    break;
                case 'config-service-vpls':
                    handle_config_service_vpls_mode($parsed_command, $input);
                    break;
                case 'config-router-ospf':
                    handle_config_router_ospf_mode($parsed_command, $input);
                    break;
                case 'config-router-ldp':
                    handle_config_router_ldp_mode($parsed_command, $input);
                    break;
                case 'config-router-bgp': 
                    handle_config_router_bgp_mode($parsed_command, $input);
                    break;
                default:
                    add_output("Internal Error: Unknown mode {$currentMode}");
            }
        }
    }
}

// 4. SAÍDA JSON FINAL 
header('Content-Type: application/json');

$routerName = empty($_SESSION['config']['name']) ? 'NOKIA CLI' : strtoupper($_SESSION['config']['name']);
$contextName = get_current_context_name();
$currentMode = $_SESSION['config']['mode'];

echo json_encode([
    'output' => $_SESSION['config']['output'] ?? [],
    'prompt' => get_prompt_string($routerName, $currentMode, $contextName),
    'mode' => $currentMode,
    'expecting_password' => $_SESSION['config']['expecting_password'] ?? false
]);
exit;