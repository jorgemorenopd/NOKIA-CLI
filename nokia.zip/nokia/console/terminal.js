document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('terminal-form');
    const input = document.getElementById('command-input');
    const outputDiv = document.getElementById('output');
    const promptDisplay = document.getElementById('prompt-display');
    const suggestionsDiv = document.getElementById('autocomplete-suggestions');

    let currentMode = 'normal'; 
    let expectingPassword = false;

    // Função para rolar o terminal para o final
    const scrollToBottom = () => {
        outputDiv.scrollTop = outputDiv.scrollHeight;
    };

    // Função para renderizar o output do servidor
    const renderOutput = (data) => {
        // Limpa o output e renderiza as linhas
        outputDiv.innerHTML = data.output.map(line => `<div>${line}</div>`).join('');
        
        // Atualiza o prompt e o modo
        promptDisplay.textContent = data.prompt;
        currentMode = data.mode;
        
        // Trata a expectativa de senha (Se o PHP disser que precisa de senha)
        if (data.expecting_password) {
            input.setAttribute('type', 'password');
            input.value = '';
            expectingPassword = true;
        } else {
            input.setAttribute('type', 'text');
            expectingPassword = false;
        }

        // Foca e rola para baixo
        input.focus();
        scrollToBottom();
    };

    // Função principal de comunicação AJAX
    const sendCommand = async (command) => {
        const url = 'router.php';
        const formData = new FormData();
        formData.append('command', command);
        
        // Se estiver esperando senha, envie a senha como 'enable <senha>'
        if (expectingPassword) {
            formData.append('expecting_password', 'true');
            // O comando será tratado como 'enable <senha>' no PHP
            // Aqui, enviamos apenas o valor do input (a senha)
        }

        try {
            const response = await fetch(url, {
                method: 'POST',
                body: formData
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            renderOutput(data);

        } catch (error) {
            outputDiv.innerHTML += `<div>% ERROR DE CONEXÃO: ${error.message}</div>`;
            scrollToBottom();
        }
    };
    
    // --- Lógica de Inicialização ---
    // Envia um comando vazio para carregar o estado inicial e o prompt
    sendCommand('');

    // --- Lógica de Envio de Comando (Intercepta o Submit) ---
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        const command = input.value.trim();
        if (command) {
            // Se estiver esperando senha, não adicione 'enable' aqui, 
            // o PHP já sabe que o próximo comando é a senha.
            const fullCommand = expectingPassword ? command : command; 
            
            // Adiciona o comando digitado ao output para feedback visual
            const promptText = promptDisplay.textContent;
            outputDiv.innerHTML += `<div>${promptText}${expectingPassword ? '********' : command}</div>`;

            sendCommand(fullCommand);
            input.value = '';
        }
    });

    // --- Lógica de Autocomplete (Melhoria 10/10) ---
    input.addEventListener('keyup', (e) => {
        const command = input.value.trim();
        
        // Aciona o autocomplete se o usuário digitar '?' ou um comando parcial
        if (e.key === '?' || (command.length > 0 && e.key !== 'Enter')) {
            // O PHP agora deve tratar o comando parcial e retornar sugestões.
            fetchSuggestions(command);
        } else {
             suggestionsDiv.style.display = 'none';
        }
        
        // Permite que o Tab selecione a primeira sugestão (opcional)
        // if (e.key === 'Tab') {
        //     // Implementação de seleção de sugestão aqui...
        // }
    });

    const fetchSuggestions = async (partialCommand) => {
         const url = 'router.php';
         const formData = new FormData();
         formData.append('action', 'suggest');
         formData.append('input', partialCommand);
         
         const response = await fetch(url, { method: 'POST', body: formData });
         const data = await response.json();
         
         if (data.suggestions && data.suggestions.length > 0) {
             suggestionsDiv.innerHTML = data.suggestions.join('<br>');
             suggestionsDiv.style.display = 'block';
             
             // Posiciona o div de sugestões
             const inputRect = input.getBoundingClientRect();
             suggestionsDiv.style.top = `${inputRect.bottom + window.scrollY}px`;
             suggestionsDiv.style.left = `${inputRect.left + window.scrollX + promptDisplay.offsetWidth}px`;
         } else {
             suggestionsDiv.style.display = 'none';
         }
    };
});